Please use GENERATED tests carefully and try not to use them on school servers.
