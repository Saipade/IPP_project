# IPP_interpreter
Implementation of IPP22code interpreter
